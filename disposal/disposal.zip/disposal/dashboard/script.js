// Simulated database
const database = [
    { id: '1', item: 'Item A' },
    { id: '2', item: 'Item B' },
    { id: '3', item: 'Item C' },
  ];
  
  // Event listener for the fetch button
  document.getElementById('fetchButton').addEventListener('click', function () {
    const idInput = document.getElementById('idInput').value.trim(); // Get input value and trim spaces
    const dataBody = document.getElementById('dataBody');
    dataBody.innerHTML = ''; // Clear previous results
  
    // Find the item in the database
    const itemData = database.find(item => item.id === idInput);
  
    if (itemData) {
      // Create a new row for the found item
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${itemData.id}</td>
        <td>${itemData.item}</td>
        <td>
          <button class="disposeButton" onclick="performAction('dispose', '${itemData.id}')">Dispose</button>
          <button class="penaltyButton" onclick="performAction('penalty', '${itemData.id}')">Penalty</button>
        </td>
      `;
      dataBody.appendChild(row);
    } else {
      // Show a message if no item was found
      const row = document.createElement('tr');
      row.innerHTML = `
        <td colspan="3" style="text-align: center; color: red;">Item not found</td>
      `;
      dataBody.appendChild(row);
    }
  });
  
  // Function to handle actions
  function performAction(action, id) {
    if (action === 'dispose') {
      const index = database.findIndex(item => item.id === id);
      if (index !== -1) {
        database.splice(index, 1); // Remove item from the database
        alert(`Item with ID ${id} has been disposed.`);
        document.getElementById('fetchButton').click(); // Refresh the table
      }
    }
}