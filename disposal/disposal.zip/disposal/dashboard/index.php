<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Item Management System</h1>
        <button id="logoutButton"><a href="../signup/">Logout</button></a>
    </header>

    <main>
        <section class="scanner">
            <h2>Scanner or ID Entry</h2>
            <input type="text" id="idInput" placeholder="Enter ID or scan here" />
            <button id="fetchButton">Fetch Data</button>
        </section>

        <section class="item-data">
            <h2>Item Data</h2>
            <table id="dataTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="dataBody">
                    <!-- Data rows will be populated here -->
                </tbody>
            </table>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Item Diposal System. All rights reserved.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>