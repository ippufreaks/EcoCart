// Show the recovery modal when the page loads (for demonstration purposes)
window.onload = function() {
    document.getElementById('recoveryModal').style.display = "block"; // Show the modal
};

// Close the modal when the user clicks on <span> (x)
document.querySelector('.close').addEventListener('click', function() {
    document.getElementById('recoveryModal').style.display = "none";
});

// Event listener for sending recovery email
document.getElementById('sendRecoveryEmail').addEventListener('click', function() {
    const email = document.getElementById('recoveryEmail').value;
    if (email) {
        // Here you can add your logic to send the recovery email (e.g., API call)
        console.log('Recovery email sent to:', email);
        alert('Recovery email sent to: ' + email);
        document.getElementById('recoveryModal').style.display = "none"; // Close the modal after sending
    } else {
        alert('Please enter a valid email address.');
    }
});

// Close the modal when the user clicks anywhere outside of the modal
window.onclick = function(event) {
    const modal = document.getElementById('recoveryModal');
    if (event.target === modal) {
        modal.style.display = "none";
    }
};