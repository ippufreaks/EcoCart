<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SecureBank - Sign Up</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="signup-container">
    <div class="form-box">
      <div class="logo">SecureBank</div>
      <div class="tagline">Join SecureBank: Your Partner in Financial Growth</div>

      <form id="signUpForm" class="form">
        <h2>Create Your Account</h2>
        <div class="input-group">
          <input type="text" id="fullName" placeholder="Full Name" required>
          <i class="icon">👤</i>
        </div>
        <div class="input-group">
          <input type="email" id="email" placeholder="Email Address" required>
          <i class="icon">📧</i>
        </div>
        <div class="input-group">
          <input type="text" id="phone" placeholder="Phone Number" required>
          <i class="icon">📞</i>
        </div>
        <div class="input-group">
          <input type="password" id="password" placeholder="Password" required>
          <i class="icon">🔒</i>
        </div>
        <div class="input-group">
          <input type="password" id="confirmPassword" placeholder="Confirm Password" required>
          <i class="icon">🔒</i>
        </div>
        <div class="checkbox">
          <input type="checkbox" id="terms" required>
          <label for="terms">I agree to the <a href="#">Terms and Conditions</a></label>
        </div>
        <button type="submit" class="btn">Sign Up</button>
       </form>

      <div class="footer">
        <p>Already have an account? <a href="../signin">Sign In</a></p>
        <small>
          <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
        </small>
      </div>
    </div>
  </div>
  <script src="scripts.js"></script>
</body>
</html>
