document.addEventListener("DOMContentLoaded", () => {
    const signUpLink = document.getElementById("signUpLink");
  
    signUpLink.addEventListener("click", (e) => {
      e.preventDefault();
      alert("Redirecting to Sign Up page (feature to be implemented)!");
    });
  
    const signInForm = document.getElementById("signInForm");
    signInForm.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Sign In successful (mock response)!");
    });
  });
  