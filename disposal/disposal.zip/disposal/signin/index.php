<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SecureBank</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <div class="form-container">
      <div class="logo">SecureBank</div>
      <div class="welcome-text">Your Trusted Financial Partner</div>

      <form id="signInForm" class="form">
        <h2>Sign In</h2>
        <div class="input-group">
          <input type="text" id="email" placeholder="Email or Username" required>
          <i class="icon">📧</i>
        </div>
        <div class="input-group">
          <input type="password" id="password" placeholder="Password" required>
          <i class="icon">🔒</i>
        </div>
        <button type="submit" class="btn">Sign In</button>
        <div class="options">
          <a href="../passwordrecovery/" class="link">Forgot Password?</a>
          </div>
      </form>

      <div id="signUpSection">
        <h3>Don't have an account? <a href="../signup/" id="signUpLink">Sign Up</a></h3>
      </div>
    </div>
  </div>
  <script src="scripts.js"></script>
</body>
</html>
