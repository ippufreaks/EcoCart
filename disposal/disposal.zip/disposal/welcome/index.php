<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Eco-Cart</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f9f9f9;
            text-align: center;
        }
        .logo {
            width: 40%;
            margin-bottom: 0px;
        }
        h1 {
            color: #333;
        }
        p {
            color: #555;
            font-size: 1.2em;
        }
        .button {
            display: inline-block;
            margin-top: 0px;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 5px;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <img src="../img/logo.png" alt="Eco-Cart Logo" class="logo">
    <h1>Welcome to Eco-Cart</h1>
    <a href="#" class="button">Get Started</a>
</body>
</html>
